//#include <blackadder.hpp>
#include <signal.h>
#include <nb_blackadder.hpp>

#include <sstream> 
#include <iostream>
#include <string>

NB_Blackadder *nb_ba;

void eventHandler(Event *ev) {
    cout << "Received Event" << endl;
    char * data = (char *) ev->data;
    if (ev->type == PUBLISHED_DATA) {
    cout << "received data: " << endl;
    cout <<  data << endl;
    }
    delete ev;
}

void publish_string_command(string target_id, char* msg) {
    unsigned int payload_size = strlen(msg);
    char * payload = (char *) malloc(payload_size);
    strcpy(payload, msg);
    string bin_target_id = hex_to_chararray(target_id);
    cout << "publishing to " << target_id << endl;
    nb_ba->publish_data(bin_target_id, DOMAIN_LOCAL, NULL, 0u, payload, payload_size);
    return;
}

/*
strategy:
publish and subscribe to our own user scope 
receive user input, publish data of command to the ds scope (hardcoded to be /00000000000000001111111111111111)
when something received at user scope, parse it!
*/
int main(int argc, char* argv[]) {
    string id;
    string prefix_id = "";
    string bin_id;
    string bin_prefix_id;
    string type;
    if (argc > 1) {
        int user_or_kernel = atoi(argv[1]);
        if (user_or_kernel == 0) {
            nb_ba = NB_Blackadder::Instance(true);
        } else {
            nb_ba = NB_Blackadder::Instance(false);
        }
    } else {
        //By Default I assume blackadder is running in user space
        nb_ba = NB_Blackadder::Instance(true);
    }
    /*Set the callback function*/
    nb_ba->setCallback(eventHandler);
    /***************************/
    cout << "Process ID: " << getpid() << endl;
    // publish the root scope @ /0000000000000000
    id = "0000000000000000";
    bin_id = hex_to_chararray(id);
    bin_prefix_id = hex_to_chararray(prefix_id);
    nb_ba->publish_scope(bin_id, bin_prefix_id, DOMAIN_LOCAL, NULL, 0);
    
    //publish my own scope @ /0000000000000000/0000000000000001
    id = "0000000000000001";
    prefix_id = "0000000000000000";
    bin_id = hex_to_chararray(id);
    bin_prefix_id = hex_to_chararray(prefix_id);
    nb_ba->subscribe_scope(bin_id, bin_prefix_id, DOMAIN_LOCAL, NULL, 0);
    string my_scope_id = "00000000000000000000000000000001";
    
    //set the target ID to the directory service
    string ds_id = "00000000000000001111111111111111";
    string bin_ds_id = hex_to_chararray(ds_id);
    //publish some data to the directory service
    /*char cmd[] = "testing 1,2,3";
    unsigned int payload_size = strlen(cmd);
    char * payload = (char *) malloc(payload_size);
    strcpy(payload, cmd);
    string target_id = "00000000000000001111111111111111";
    string bin_target_id = hex_to_chararray(target_id);
    cout << "publishing to " << target_id << endl;
    nb_ba->publish_data(bin_target_id, DOMAIN_LOCAL, NULL, 0u, payload, payload_size);
    //publish_string_command("00000000000000001111111111111111", "add(123,abc)");*/

    cout << "acceptable commands:" << endl;
    cout << "put,key,val" << endl;
    cout << "get,key,scope"<< endl;
    
    while (true) {
    cout << ":";
    char cmd [1000];
    char * payload;
    unsigned int payload_size;
    cin.width(1000);
    cin >> cmd;
    if (strcmp(cmd, "quit") == 0) goto ending;
    /*
    istringstream liness( cmd );
    string msg, key, val;
    getline( liness, msg, ',' );
    getline( liness, key, ',' );
    if (strcmp(msg.c_str(), "get") == 0) { val = my_scope_id; }
    else {getline( liness, val, ',' );}
    char final_cmd[1000];
    final_cmd = msg+key+val;
    cout << final_cmd << endl;*/
    payload_size = strlen(cmd);
    payload = (char *) malloc(payload_size);
    strcpy(payload, cmd);
    nb_ba->publish_data(bin_ds_id, DOMAIN_LOCAL, NULL, 0u, payload, payload_size);

    }
    
ending:
    nb_ba->join();
    nb_ba->disconnect();
    delete nb_ba;
    cout << "exiting...." << endl;
    return 0;
}
