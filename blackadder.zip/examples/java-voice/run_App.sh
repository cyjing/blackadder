#!/bin/sh
java -cp ./build:./lib/* eu.pursuit.vopsi.gui.VoPSI_App -f $1
