#! /bin/bash

java -cp ./bin:./lib/* eu.pursuit.vopsi.gui.VoPSI_App $@
